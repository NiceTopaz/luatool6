cmake_minimum_required(VERSION 3.10)
project(clavintool C)

set(LUA_DIR ${CMAKE_CURRENT_SOURCE_DIR}/lua)
file(GLOB LUA_SOURCES ${LUA_DIR}/*.c)
list(FILTER LUA_SOURCES EXCLUDE REGEX ".*/(lua|luac|ltests)\\.c$")

add_library(clavintool SHARED luabridge.c ${LUA_SOURCES})

# LUA_USE_POSIX: popen/mkstemp/... ; LUA_COMPAT_5_2: bit32, math.pow & friends (old scripts)
target_compile_definitions(clavintool PRIVATE LUA_USE_POSIX LUA_COMPAT_5_2)
target_compile_options(clavintool PRIVATE -O2 -fvisibility=hidden)
target_link_libraries(clavintool log m)
